<?php
// Parámetros de conexión a la base de datos
define('HOST', 'localhost');
define('DBNAME', 'sistema_reservas');
define('USER', 'root');
define('PASS', 'MANAGER');

?>