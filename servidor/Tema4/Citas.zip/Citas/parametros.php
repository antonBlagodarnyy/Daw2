<?php

// Configuración de base de datos
define("HOST",'localhost');
define("DB",'citascelebres_db');
define("USUARIO",'root');
define("CLAVE",'MANAGER');
