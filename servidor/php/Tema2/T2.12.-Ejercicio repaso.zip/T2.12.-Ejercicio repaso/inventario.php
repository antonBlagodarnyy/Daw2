<?php
interface inventario {
    public function listado();
}