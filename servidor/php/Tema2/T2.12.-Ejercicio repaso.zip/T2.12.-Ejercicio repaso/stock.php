<?php
interface stock{

}