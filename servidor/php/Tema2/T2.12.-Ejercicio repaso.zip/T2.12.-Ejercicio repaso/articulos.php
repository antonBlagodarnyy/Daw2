<?php
require_once("productos.php");

class articulos extends productos {
    private $garantia;
    private $precioUnitario;

    public function coste(){
        
    }
}