<?php class administradores extends Usuario {
    
}