<?php
class servicios extends productos {
    private $periodoPrueba;
    private $cuotaMensual;

    public function coste(){
        
    }
}