<?php
interface iEntregable{
    public function entregar();
    public function devolver();
    public function isEntregado();

}