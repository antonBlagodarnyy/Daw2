<?php
    // Declaración de parámetos de conexión. Son constantes.
    define('HOST',      'localhost');
    define('DBNAME',    'productos');
    define('USERNAME',  'root');
    define('PASSWORD',  'MANAGER');
?>